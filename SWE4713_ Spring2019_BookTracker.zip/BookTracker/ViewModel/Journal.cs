﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BookTracker.ViewModel
{
    public class Transactions
    {

        
        public decimal transactionAmount { get; set; }
        public int transactionType { get; set; }
        public int acctNo { get; set; }
     
    }

}